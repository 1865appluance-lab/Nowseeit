# SimpleAndroidApp (with GitHub CI)

Minimal Android Studio Kotlin project with a counter button.

## GitHub Actions CI
This project includes `.github/workflows/android.yml` which:
- Builds the app on every push to `main`
- Uploads the debug APK as an artifact

## How to use
1. Push this project to GitHub.
2. Open the "Actions" tab in your repo.
3. Select the "Android CI" workflow run.
4. Download the generated `app-debug.apk` artifact.
