package com.example.simpleandroidapp

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private var counter = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvCounter = findViewById<TextView>(R.id.tvCounter)
        val btnPress = findViewById<MaterialButton>(R.id.btnPress)

        btnPress.setOnClickListener {
            counter++
            tvCounter.text = "Presses: $counter"
            if (counter % 5 == 0) {
                Toast.makeText(this, "Nice! $counter presses", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
